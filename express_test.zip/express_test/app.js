const express = require("express");
const app = express();
const path = require("path");
const mongoose = require("mongoose");
const Post = require('./models/Post');;

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: false }));

mongoose.connect("mongodb://127.0.0.1/express002db");
const db = mongoose.connection;
db.on("error", console.error.bind("MongoDB connection error at express002db"));

app.get("/", function(req, res) {
    Post.find(function(err, rtn) {
        if(err) throw err;
        res.render('index', { posts: rtn});
    });
});

app.get("/postadd", function(req, res) {
    res.render("postadd");
});

app.post("/postadd", function(req, res) {
    console.log(req.body);
    const post = new Post();
    post.title = req.body.title;
    post.body = req.body.body_text;
    post.img = req.body.img;
    post.save(function(err, rtn) {
        if(err) throw err;
        console.log(rtn);
        res.redirect('/');
    });
});

app.get('/postupdate/:id', function(req, res) {
    Post.findById(req.params.id, function(err, rtn) {
        if(err) throw err;
        res.render('postupdate', { post: rtn});
    });
});

app.post('/postupdate', function(req, res) {
    const update = {
        title : req.body.title,
        body : req.body.body_text,
        img : req.body.img,
    };
    Post.findByIdAndUpdate(req.body.id, { $set: update}, function(err, rtn) {
        if(err) throw err;
        res.redirect('/');
    });
});

app.get('/postdelete/:id', function(req, res) {
    Post.findByIdAndDelete(req.params.id, function(err, rtn) {
        if(err) throw err;
        res.redirect("/");
    });
});

app.get('/postdetail/:id', function(req, res) {
    Post.findById(req.params.id, function(err, rtn) {
        if(err) throw err;
        console.log(rtn);
        res.render("postdetail", { postt:rtn });
    }); 
});

app.listen(80, function() {
    console.log("Server is running...");
});